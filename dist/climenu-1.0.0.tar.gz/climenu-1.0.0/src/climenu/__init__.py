from .menuMaker import Menu
__version__ = 1.0

